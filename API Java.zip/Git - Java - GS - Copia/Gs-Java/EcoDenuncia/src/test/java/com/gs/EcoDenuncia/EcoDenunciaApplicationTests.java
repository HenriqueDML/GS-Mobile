package com.gs.EcoDenuncia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoDenunciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
