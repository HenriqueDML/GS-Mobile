package com.gs.EcoDenuncia.model;

public record Token(
        String token,
        String email
) {
}
