package com.gs.EcoDenuncia.model;

public record Credentials(
        String email,
        String senha
) {
}
