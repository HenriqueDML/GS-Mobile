package com.gs.EcoDenuncia.model;

public enum RoleType {
    ADMIN,
    USER;


}
